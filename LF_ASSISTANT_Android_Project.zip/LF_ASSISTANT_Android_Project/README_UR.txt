LF ASSISTANT — Fatima (ابتدائی Android پروجیکٹ)

یہ ایک حقیقی Android Studio سورس پروجیکٹ ہے، تیار شدہ APK نہیں۔

اس ورژن میں:
- LF ASSISTANT نام اور Fatima اسسٹنٹ
- اردو ٹیکسٹ چیٹ
- فون کی Speech Recognition کے ذریعے آواز سے ان پٹ
- اردو Text-to-Speech جواب (فون کی TTS زبان پر منحصر)
- YouTube اور Google کھولنے کی کوشش
- Alarm ایپ کھولنا
- "یاد رکھو ..." کے ذریعے مقامی نوٹس محفوظ کرنا
- "میری یادیں" کہنے پر محفوظ نوٹس دکھانا

حدود:
- یہ ابھی مکمل ChatGPT جیسا AI نہیں؛ اس میں AI ماڈل/API کنکشن شامل نہیں۔
- یہ تمام فون کا غیر محدود کنٹرول نہیں کرتا۔
- کال/میسج بھیجنا، اسکرین بند ہونے پر wake-word سننا، بیک گراؤنڈ سروس، اور مکمل ذہین/خودکار میموری ابھی شامل نہیں۔
- کوئی پاس ورڈ یا نجی معلومات اس ڈیمو میں محفوظ نہ کریں۔

APK بنانے کا طریقہ:
1. کمپیوٹر پر Android Studio انسٹال کریں۔
2. Android Studio میں "Open" منتخب کر کے اس فولڈر کو کھولیں۔
3. Gradle Sync مکمل ہونے دیں۔
4. فون کو USB debugging کے ذریعے جوڑیں یا emulator استعمال کریں۔
5. Run دبائیں، یا Build > Build APK(s) منتخب کریں۔

اگلا ترقیاتی مرحلہ:
- محفوظ backend کے ذریعے AI model شامل کرنا (API key ایپ کے اندر نہیں رکھنی)
- رضامندی پر مبنی Android permissions اور actions
- یاد دہانیوں کا نظام اور memory settings
- privacy controls، memory دیکھنے/مٹانے کے اختیارات

درکار ماحول: Android Studio، Android SDK 35، JDK 17 یا compatible Android Studio bundled JDK.
