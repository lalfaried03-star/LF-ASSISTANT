package com.lfassistant.app

import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private lateinit var prefs: android.content.SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("lf_memory", MODE_PRIVATE)
        tts = TextToSpeech(this, this)
        buildScreen()
        addMessage("السلام علیکم! میں فاطمہ ہوں، LF ASSISTANT۔ ابھی میں ابتدائی ورژن ہوں۔ تم مجھ سے لکھ کر یا آواز سے بات کر سکتے ہو۔", false)
    }

    private fun buildScreen() {
        val base = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(0xFF0B1020.toInt())
        }
        val title = TextView(this).apply {
            text = "LF ASSISTANT"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "Fatima • Your Personal Assistant"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xFFB9B4D8.toInt())
        }
        chat = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 14, 14, 14)
        }
        val scroll = ScrollView(this).apply {
            addView(chat)
            setBackgroundColor(0xFF151D32.toInt())
        }
        input = EditText(this).apply {
            hint = "اپنا پیغام لکھو…"
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9AA6C2.toInt())
            setSingleLine(true)
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val send = Button(this).apply { text = "بھیجو"; setOnClickListener { sendText() } }
        val mic = Button(this).apply { text = "🎙 آواز"; setOnClickListener { startVoiceInput() } }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(send)
        row.addView(mic)

        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        quick.addView(Button(this).apply { text = "الارم"; setOnClickListener { setAlarm() } })
        quick.addView(Button(this).apply { text = "YouTube"; setOnClickListener { openAppOrWeb("com.google.android.youtube", "https://youtube.com") } })
        quick.addView(Button(this).apply { text = "یاد رکھو"; setOnClickListener { rememberFromInput() } })

        base.addView(title)
        base.addView(subtitle)
        base.addView(space(16))
        base.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        base.addView(space(10))
        base.addView(row)
        base.addView(quick)
        setContentView(base)
    }

    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, h) }

    private fun addMessage(text: String, fromUser: Boolean) {
        val tv = TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(14, 10, 14, 10)
            setBackgroundColor(if (fromUser) 0xFF5145A8.toInt() else 0xFF26324C.toInt())
        }
        val p = LinearLayout.LayoutParams(-1, -2)
        p.setMargins(0, 7, 0, 7)
        chat.addView(tv, p)
    }

    private fun sendText() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        addMessage(text, true)
        handleCommand(text)
    }

    private fun handleCommand(raw: String) {
        val q = raw.lowercase(Locale.ROOT)
        val answer = when {
            q.contains("میرا نام") || q.contains("my name") -> {
                val saved = prefs.getString("user_name", null)
                if (saved == null) "ابھی تم نے اپنا نام مجھے یاد نہیں کروایا۔" else "تمہارا نام $saved ہے۔"
            }
            q.startsWith("یاد رکھو ") || q.startsWith("remember ") -> {
                val memory = raw.substringAfter(' ').trim()
                val old = prefs.getString("notes", "")
                prefs.edit().putString("notes", (old + "\n" + memory).trim()).apply()
                "ٹھیک ہے، میں نے یہ بات اسی فون میں محفوظ کر لی: $memory"
            }
            q.contains("میری یادیں") || q.contains("what do you remember") -> {
                prefs.getString("notes", "").orEmpty().ifBlank { "ابھی کوئی بات محفوظ نہیں۔" }
            }
            q.contains("یوٹیوب") || q.contains("youtube") -> {
                openAppOrWeb("com.google.android.youtube", "https://youtube.com")
                "YouTube کھولنے کی کوشش کر رہی ہوں۔"
            }
            q.contains("گوگل") || q.contains("google") -> {
                openAppOrWeb("com.google.android.googlequicksearchbox", "https://google.com")
                "Google کھولنے کی کوشش کر رہی ہوں۔"
            }
            q.contains("الارم") || q.contains("alarm") -> {
                setAlarm()
                "الارم ایپ کھول دی ہے۔ وقت تم خود منتخب کر لو۔"
            }
            q.contains("اداس") || q.contains("پریشان") || q.contains("sad") -> "میں تمہاری بات سن رہی ہوں۔ آرام سے بتاؤ کیا ہوا، پھر مل کر حل سوچتے ہیں۔"
            q.contains("سلام") || q.contains("السلام") || q.contains("hello") -> "وعلیکم السلام! بتاؤ، آج کیا کرنا ہے؟"
            else -> "میں ابھی بنیادی ورژن ہوں۔ میں فون کے چند کام کر سکتی ہوں اور تمہاری لکھی ہوئی یادیں محفوظ کر سکتی ہوں۔ مکمل AI گفتگو کے لیے محفوظ AI سرور کنکشن اگلے مرحلے میں شامل کرنا ہوگا۔"
        }
        addMessage(answer, false)
        speak(answer)
    }

    private fun rememberFromInput() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) {
            addMessage("پہلے نیچے لکھو: یاد رکھو، پھر یہ بٹن دباؤ۔", false)
            return
        }
        prefs.edit().putString("notes", (prefs.getString("notes", "").orEmpty() + "\n" + text).trim()).apply()
        input.setText("")
        addMessage("یہ بات اس فون میں محفوظ کر لی: $text", false)
    }

    private fun setAlarm() {
        try {
            startActivity(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_SKIP_UI, false))
        } catch (_: Exception) {
            addMessage("الارم ایپ دستیاب نہیں ملی۔", false)
        }
    }

    private fun openAppOrWeb(packageName: String, url: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        try {
            startActivity(launch ?: Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }

    private fun startVoiceInput() {
        try {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "فاطمہ سے بات کریں")
            }
            @Suppress("DEPRECATION")
            startActivityForResult(i, 41)
        } catch (_: Exception) {
            addMessage("اس فون میں آواز سے لکھنے کی سہولت دستیاب نہیں۔", false)
        }
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 41 && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!words.isNullOrBlank()) {
                input.setText(words)
                sendText()
            }
        }
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "lf_reply")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("ur", "PK")
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
